> python3 18.py
Run the program.
